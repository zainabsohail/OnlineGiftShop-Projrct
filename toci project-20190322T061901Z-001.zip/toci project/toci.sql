-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 05, 2019 at 11:03 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `toci`
--
CREATE DATABASE IF NOT EXISTS `toci` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `toci`;

-- --------------------------------------------------------

--
-- Table structure for table `cat`
--

DROP TABLE IF EXISTS `cat`;
CREATE TABLE `cat` (
  `cat_id` varchar(50) NOT NULL,
  `cat_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cat`
--

INSERT INTO `cat` (`cat_id`, `cat_name`) VALUES
('1', 'flowers'),
('2', 'cakes'),
('3', 'chocolates'),
('4', 'gift basket');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `product_id` varchar(50) NOT NULL,
  `product_cat` varchar(50) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `price` double NOT NULL,
  `availability` varchar(10) NOT NULL,
  `product_img` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_cat`, `product_name`, `price`, `availability`, `product_img`) VALUES
('5c54324fc628d', 'flowers', 'lilies', 347, 'yes', 'lilies.jpg'),
('5c547358c422c', 'cakes', 'chocolate cake', 1200, 'yes', 'cake.jpg'),
('5c558b9fc7129', 'gift basket', 'chocolate basket', 2000, 'yes', 'ch.jpg'),
('5c558bb6f10f1', 'gift basket', 'chocolate basket', 1500, 'yes', 'ch2.jpg'),
('5c558bd7ae5b1', 'gift basket', 'flower basket', 2500, 'yes', 'r2.jpg'),
('5c558bf0873f1', 'gift basket', 'combo', 3000, 'yes', 'ch4.jpg'),
('5c558c207281c', 'chocolates', 'kitkat', 2000, 'yes', 'ch6.jpg'),
('5c558d857f55b', 'flowers', 'lilies', 1500, 'yes', 'r5.jpg'),
('5c558dab890d2', 'flowers', 'yellow and white roses', 1800, 'yes', 'r4.jpg'),
('5c558dc280712', 'flowers', 'roses', 1000, 'yes', 'r3.jpg'),
('5c558dd537f27', 'flowers', 'roses', 2000, 'yes', 'f5.jpg'),
('5c558de9bef7b', 'flowers', 'red roses', 2000, 'yes', 'r1.jpg'),
('5c558e03b092f', 'cakes', 'delizia cake', 2000, 'yes', 'd2.jpg'),
('5c558e1a390e5', 'cakes', 'delizia cake', 1500, 'yes', 'd3.jpg'),
('5c558e51ade00', 'cakes', 'delizia cake', 2200, 'yes', 'd4.jpg'),
('5c558e5fe4591', 'cakes', 'delizia cake', 2000, 'yes', 'd5.jpg'),
('5c558e72304e4', 'cakes', 'delizia cake', 1200, 'yes', 'd6.jpg'),
('5c558e8613ccc', 'cakes', 'delizia cake', 1500, 'yes', 'd7.jpg'),
('5c558ea582b95', 'cakes', 'hobnob cake', 1200, 'yes', 'h1.jpg'),
('5c558ebb223f1', 'cakes', 'hobnob cake', 1200, 'yes', 'h2.jpg'),
('5c558ed032f54', 'cakes', 'hobnob cake', 1800, 'yes', 'h3.jpg'),
('5c558f313ec77', 'cakes', 'sachas cake', 2000, 'yes', 's1.jpg'),
('5c558f4c99bb6', 'cakes', 'sachas cake', 1800, 'yes', 's2.jpg'),
('5c558f60953c7', 'cakes', 'sachas cake', 2000, 'yes', 's3.jpg'),
('5c558f757d874', 'cakes', 'sachas cake', 2000, 'yes', 's4.jpg'),
('5c558fce709b5', 'chocolates', 'dairy milk', 1200, 'yes', 'ch7.jpg'),
('5c558fe82f799', 'chocolates', 'combo', 2000, 'yes', 'ch5.jpg'),
('5c558ffb72d0c', 'chocolates', 'combo', 2000, 'yes', 'ch4.jpg'),
('5c55901e7b378', 'chocolates', 'kitkat', 2000, 'yes', 'ch9.jpg'),
('5c55904395a0e', 'chocolates', 'combo', 2500, 'yes', 'ch.jpg'),
('5c55914c01851', 'chocolates', 'combo', 2000, 'yes', 'ch2.jpg'),
('5c55915f45b49', 'chocolates', 'kitkat', 3000, 'yes', 'ch3.jpg'),
('5c55916ece49c', 'chocolates', 'combo', 2000, 'yes', 'ch5.jpg'),
('5c55917f883a7', 'chocolates', 'dairy milk', 3000, 'yes', 'ch6.jpg'),
('5c55918fd9332', 'chocolates', 'combo', 2000, 'yes', 'ch8.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `user_id` varchar(50) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `password` varchar(10) NOT NULL,
  `email` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `password`, `email`) VALUES
('5c556f04ef5f3', 'zainab', '12345', 'Zainabsohail09@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cat`
--
ALTER TABLE `cat`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
