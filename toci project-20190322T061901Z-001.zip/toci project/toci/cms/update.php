<?php require_once('includes/head.php')?>
<title>Update Product</title>
</head>
<!-- END HEAD -->

<!-- BEGIN BODY -->
<body class="page-header-fixed">


<!-- BEGIN HEADER -->
<?php require_once('includes/header.php'); ?>
<!-- END HEADER -->

<!-- BEGIN CONTAINER -->
<div class="page-container row-fluid">

    <!-- BEGIN SIDEBAR -->
    <?php require_once('includes/sidebar_menu.php'); ?>
    <!-- END SIDEBAR -->


    <!-- BEGIN PAGE -->
    <div class="page-content">
        <!-- BEGIN SAMPLE PORTLET CONFIGURATION MODAL FORM-->
        <div id="portlet-config" class="modal hide">
            <div class="modal-header">
                <button data-dismiss="modal" class="close" type="button"></button>
                <h3>portlet Settings</h3>
            </div>
            <div class="modal-body">
                <p>Here will be a configuration form</p>
            </div>
        </div>
        <!-- END SAMPLE PORTLET CONFIGURATION MODAL FORM-->
        <!-- BEGIN PAGE CONTAINER-->
        <div class="container-fluid">

            <!-- BEGIN PAGE HEADER-->
            <div class="row-fluid">
                <div class="span12">

                    <!-- BEGIN STYLE CUSTOMIZER -->
                    <?php require_once('includes/customizer.php'); ?>
                    <!-- END BEGIN STYLE CUSTOMIZER -->


                    <h3 class="page-title">
                        Update
                        <small>Products</small>
                    </h3>
                    <ul class="breadcrumb">
                        <li>
                            <i class="icon-home"></i>
                            <a href="index.php">Home</a>
                            <span class="icon-angle-right"></span>
                        </li>
                        <li>
                            <a href="#">Update Products</a>
                            <span class="icon-angle-right"></span>
                        </li>
                        <li><a href="allitems.php">Back</a></li>
                    </ul>
                </div>
            </div>
            <!-- END PAGE HEADER-->

            <!-- BEGIN PAGE CONTENT-->
            <div class="row-fluid">
                <div class="span12">
                    <!-- BEGIN SAMPLE FORM PORTLET-->

                    <div class="portlet box blue tabbable">
                        <div class="portlet-title">
                            <div class="caption">
                                <i class="icon-reorder"></i>
                                <span class="hidden-480">Update</span>
                            </div>
                        </div>
                        <div class="portlet-body form">
                            <div class="tabbable portlet-tabs">
                                <ul class="nav nav-tabs">
                                    <li></li>
                                    <li></li>
                                    <li></li>

                                </ul>

                                <br/><br/><br/>

                                <div class="tab-content">
                                    <div class="tab-pane active" id="portlet_tab1">
                                        <!-- BEGIN FORM-->

                                        <form   action="" class="form-horizontal" method="POST" enctype="multipart/form-data">
                                            <?php
                                            
                                            $product_id = $_GET['id'];
                                            $query ="select * from products where product_id= '$product_id'";
                                            $run = mysqli_query($conn, $query);
                                            
                                 
                                            while($row = mysqli_fetch_array($run))
                                            {
                                                $product_cat = $row['product_cat'];
                                                $product_name =$row['product_name'];
                                                $price = $row['price'];
                                                $availability = $row['availability'];
                                                $product_img =$row['product_img'];
                                            }
                                            ?>
                                                <div class="control-group">
                                                    <label class="control-label">Select Option To Add</label>
                                                    <div class="controls">
                                                        <select class="m-wrap medium" name="product_cat" required>
                                                      
                                                            <option value="<?php echo $product_cat?>"><?php echo $product_cat?></option>
                                                            <?php 
                                                            $products = mysqli_query($conn,"select * from cat");
                                                            while($row = mysqli_fetch_array($products)){
                                                                    ?>
                                                            <option value="<?php echo $row['cat_name']; ?>"><?php echo $row['cat_name']; ?></option>
                                                            <?php } ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            <div class="control-group">
                                                <label class="control-label">Product Name</label>
                                                <div class="controls">
                                                    <input type="text" class="m-wrap medium" name="product_name" value="<?php echo $product_name?>" required/>
                                                </div>
                                            </div>
                                            <div class="control-group">
                                                <label class="control-label">Price</label>
                                                <div class="controls">
                                                    <input type="text" class="m-wrap medium" name="price"  value="<?php echo $price?>" required/>
                                                </div>
                                            </div>
                                            <div class="control-group">
                                                <label class="control-label">Availability</label>
                                                <div class="controls">
                                                    <input type="text" class="m-wrap medium" name="availability" value="<?php echo $availability?>" required/>
                                                </div>
                                            </div>
                                         <div class="control-group">
                                                <label class="control-label">Product Image</label>
                                                <div class="controls">
                                                    <input type="file" class="m-wrap medium" name="product_img" accept="iamge/*"   multiple/>
                                                    <img src="../images/<?php echo $product_img; ?>" style="width: 100px; height:100px"/>
                                                </div>
                                                </div>

                                            <div class="form-actions">
                                                <button type="submit" name="submit" class="btn blue"><i class="icon-ok"></i> Save</button>
                                                <a href="allitems.php" class="btn">Cancel</a>
                                            </div>
                                        </form>
                                       
                                        <?php
                                        if(isset($_POST['submit'])){
                                        $product_id = $_GET['id'];
                                        $product_cat = $_POST['product_cat'];
                                        $product_name = $_POST['product_name'];
                                        $price = $_POST['price'];
                                        $availability = $_POST['availability'];
                                        $product_img =$_FILES['product_img']['name'];
                                        $pro_tmp=$_FILES['product_img']['tmp_name'];
                                        move_uploaded_file($pro_tmp,"../images/$product_img");
                                        
                                        if(is_uploaded_file($pro_tmp)){
                                        move_uploaded_file($pro_tmp,"../images/$product_img");
                                            $query = "update products set product_cat='$product_cat' , product_name='$product_name',price='$price',availability='$availability' , product_img = '$product_img' where product_id='$product_id'";
                                        
                                         $run= mysqli_query($conn, $query);
                                        }
                                        else{
                                                 $query = "update products set product_cat='$product_cat' , product_name='$product_name', price='$price',availability='$availability' , product_img = '$product_img' where product_id='$product_id'";
                                        } 
                                         $run= mysqli_query($conn, $query);
                                         if($run == true ){
                                             echo "product has been updated";
                                         }else
                                         {
                                             echo "something went wrong";
                                         }
                                        }
                                        ?>
                                        <!-- END FORM-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>