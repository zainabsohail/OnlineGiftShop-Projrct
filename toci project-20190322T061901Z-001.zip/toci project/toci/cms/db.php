<?php
//$servername = "localhost";
//$username = "root";
//$password = "";


// Create connection
$conn = new mysqli("localhost", "root","","toci");

// Check connection
if ($conn) {
 

} 
else
{
    
    echo " no connection";
}
mysqli_select_db($conn, "toci")
?>


