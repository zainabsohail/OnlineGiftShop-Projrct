<?php include 'cms/db.php'; ?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.5">
    <title>Online Gift Shop</title>
    <!--this is arvo font-->
    <link href="https://fonts.googleapis.com/css?family=Arvo" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">
    
    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
      }
      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style> 
        <!-- Custom styles for this template -->
        <link href="custom.css" rel="stylesheet">
  </head>
  <body>
   <?php include 'includes/header.php';?>
      <main role="main" style="padding-top:10px;">
 <div id="get_involved">
    <div class="container homepage">
        <div class="row" >
        <h2>CAKES</h2>
        <h6 style="text-align:right;"><a href="delizia.php">view all</a></h6>
         <?php
            $query ="select * from products where product_cat = 'cakes' limit 3 offset 0";
            $run = mysqli_query($conn, $query);
            while($row= mysqli_fetch_array($run)){
          ?>
         <div class="col-md-4"  style="border: 1px solid #cccccc;margin:10px;padding-top:20px;width:300px; height:500px;">
             <div class="col-lg-3 col-md-4 col-sm-6"style="padding-top:20px;">
              <img src="images/<?php echo $row['product_img'];?>" width="247px" height="300px">
            <h5 style="font-weight:bold;"><?php echo $row['product_name'] ,$row['price'];?></h5>
            <div class="card-body">
              <p class="card-text"></p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                    <a href="images/<?php echo $row['product_img'];?>"><button type="button" class="btn btn-sm btn-outline-secondary">View</button></a>
                    <a href="images/<?php echo $row['product_img'];?>"><button type="button" class="btn btn-sm btn-outline-secondary">Add To Cart</button></a>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <?php }?>
    </div> 
      
  </div> <!-- /container -->
  </div>
  <div id="wwa">
    <div class="container homepage">
      <div class="row">
        <h2>FLOWERS</h2>
        <h6 style="text-align:right;"><a href="flower.php">view all</a></h6>
         <?php
            $query ="select * from products where product_cat='flowers' limit 3 offset 0";
            $run = mysqli_query($conn, $query);
            while($row= mysqli_fetch_array($run)){
          ?>
        <div class="col-md-4"  style="border: 1px solid #cccccc;margin:10px;padding-top:20px;width:300px; height:500px;">
          <div class="col-lg-3 col-md-4 col-sm-6" style="padding-top:20px;">
             
              <img src="images/<?php echo $row['product_img'];?>" width="247px" height="300px">
            <h5 style="font-weight:bold;"><?php echo $row['product_name'];?> Price: <?php echo $row['price'];?></h5>
            <div class="card-body">
              <p class="card-text"></p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                    <a href="images/<?php echo $row['product_img'];?>"><button type="button" class="btn btn-sm btn-outline-secondary">View</button></a>
                    <a href="images/<?php echo $row['product_img'];?>"><button type="button" class="btn btn-sm btn-outline-secondary">Add To Cart</button></a>
                </div>
              </div>
            </div>
          </div>
              
          </div>
     
        <?php }?>
    </div> 
      
    </div>
  </div>
  <div id="get_involved">
    <div class="container homepage">
       <div class="row">
        <h2>CHOCOLATES</h2>
        <h6 style="text-align:right;"><a href="choco.php">view all</a></h6>
         <?php
            $query ="select * from products where product_cat='chocolates' limit 3 offset 0";
            $run = mysqli_query($conn, $query);
            while($row= mysqli_fetch_array($run)){
          ?>
        <div class="col-md-4"  style="border: 1px solid #cccccc;margin:10px;padding-top:20px;width:300px; height:500px;">
          <div class="col-lg-3 col-md-4 col-sm-6" style="padding-top:20px;">
              <img src="images/<?php echo $row['product_img'];?>" width="247px" height="300px">
            <h5 style="font-weight:bold;"><?php echo $row['product_name'];?> Price: <?php echo $row['price'];?></h5>
            <div class="card-body">
              <p class="card-text"></p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                    <a href="images/<?php echo $row['product_img'];?>"><button type="button" class="btn btn-sm btn-outline-secondary">View</button></a>
                    <a href="images/<?php echo $row['product_img'];?>"><button type="button" class="btn btn-sm btn-outline-secondary">Add To Cart</button></a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <?php }?>
    </div> 
      
  </div> <!-- /container -->
  </div>
   <div id="wwa">
    <div class="container homepage">
      <div class="row">
        <h2>GIFT BASKETS</h2>
        <h6 style="text-align:right;"><a href="gift.php">view all</a></h6>
         <?php
            $query ="select * from products where product_cat='gift basket' limit 3 offset 0";
            $run = mysqli_query($conn, $query);
            while($row= mysqli_fetch_array($run)){
          ?>
        <div class="col-md-4" style="border: 1px solid #cccccc;margin:10px;padding-top:20px;width:300px; height:500px;text-align: center;">
          <div class="col-lg-3 col-md-4 col-sm-6">
            <img src="images/<?php echo $row['product_img'];?>" width="247px" height="300px">
            <h5 style="font-weight:bold;"><?php echo $row['product_name'];?> Price: <?php echo $row['price'];?></h5>
            <div class="card-body">
              <p class="card-text"></p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                    <a href="images/<?php echo $row['product_img'];?>"><button type="button" class="btn btn-sm btn-outline-secondary">View</button></a>
                    <a href="images/<?php echo $row['product_img'];?>"><button type="button" class="btn btn-sm btn-outline-secondary">Add To Cart</button></a>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <?php }?>
    </div> 
      
    </div>
  </div>
</main>

      <footer>
      
  </footer>
  
      
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script> 
</body>
</html>
