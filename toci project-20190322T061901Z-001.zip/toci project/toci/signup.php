
<html lang="en">
    <?php include 'cms/db.php'; ?>
<?php session_start();?>
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.5">
   
<link href="https://fonts.googleapis.com/css?family=Arvo" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet" >
    <title>Sign Up</title>


    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
    <!-- Custom styles for this template -->
    <link href="custom.css" rel="stylesheet">
  </head>
<body>
     <?php include 'includes/header.php';?>
     <div class="cbg">
    <div class="container">
        
    <div class="col-md-12">
        <div id="logbox" style="padding-top:20px;">
        <h2 style="text-align:center;">Sign Up!</h2>
        <form method="post">
      
        <input name="name" type="text" placeholder="Enter your username"  autofocus="autofocus" required="required" class="input pass"/>
        <input name="password" type="password" placeholder="Choose a password" required="required" class="input pass"/>
 
        <input name="email" type="email" placeholder="Email address" class="input pass"/>
        <input type="submit" value="Sign me up!" name="submit" class="inputButton"/>
      </form>
    </div>
        <?php
            if(isset($_POST['submit']))
            {
                $uname=$_POST['name'];
                $upassword=$_POST['password'];
                $uemail=$_POST['email'];
                $user_id = uniqid();
                
                $query = "insert into user (user_id ,user_name,password,email)values('$user_id','$uname','$upassword','$uemail')";
                if (mysqli_query($conn, $query)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $query . "<br>" . mysqli_error($conn);
}
            }
        ?>
   </div>
    <!--col-md-6-->
   
  </div>
  </div> 
</body>
