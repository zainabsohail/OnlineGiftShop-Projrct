
<!doctype html>
<html lang="en">
<?php include 'cms/db.php';?>
<?php session_start(); ?>
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.5">
   
<link href="https://fonts.googleapis.com/css?family=Arvo" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet" >

    <title>Online Gift Shop</title>

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
      
    </style>
    <!-- Custom styles for this template -->
    <link href="home.css" rel="stylesheet">


</head>
  <body>
      <?php include 'includes/header.php';?>
    <main role="main">
    <div class="container" style="padding-top:10rem;">
    
	<div class="row justify-content-center">
                        <div class="col-12 col-md-10 col-lg-8">
                            <form method="post">
                                <div class="card-body row no-gutters align-items-center">
                                   
                                    <div class="col">
                                        <input name="keyword" class="form-control form-control-lg form-control-borderless" type="search" placeholder="Search books">
                                        <button name="submit" class="btn btn-lg btn-success" type="submit" style="display: inline-block">Search</button>
                                    </div>
                
                                </div>
                            </form>
                            <?php if(isset($_POST['submit']))
                            {
                                $keyword =$_POST['keyword'];
                                $query =" select * from products where product_name = '$keyword'";
                                $run = mysqli_query($conn, $query);
                                
                                if(mysqli_num_rows($run) < 1)
                                {
                                    echo 'not found!';
                                }
                                else
                                {
                                    while($row= mysqli_fetch_array($run))
                                            
                                    { ?>
                            <div class="container">
                                        <div class="col-md-4" >
                                           <div class="card mb-4 shadow-sm">
                                               <img src="images/<?php echo $row['product_img'];?>"width="200px" height="230px"style="padding-top: 5rem;">
                                             <h5 style="font-weight:bold;"><?php echo $row['product_name'];?> Price: <?php echo $row['price'];?></h5>
                                             <div class="card-body">
                                               <p class="card-text"></p>
                                               <div class="d-flex justify-content-between align-items-center">
                                                 <div class="btn-group">
                                                     <a href="images/<?php echo $row['product_img'];?>"><button type="button" class="btn btn-sm btn-outline-secondary">View</button></a>
                                                 </div>
                                             </div>
                                           </div>
                                         </div>
                                     </div>
                              <?php }?>
                                <?php }?>
                          <?php }?>
 
                        </div>
                        </div>
        </div>
    </div>

  <div class="album py-5 bg-light" style="padding-top: 5rem; padding-bottom: 4rem;">
       
    <div class="container">
      <div class="row">
        <?php
           $query ="select * from products where product_cat = 'chocolates' ";
            $run = mysqli_query($conn, $query);
            while($row= mysqli_fetch_array($run)){
          ?>
       <div class="col-md-4">
          <div class="card mb-4 shadow-sm">
              <img src="images/<?php echo $row['product_img'];?>"width="148px" height="223px">
            <h5 style="font-weight:bold;"><?php echo $row['product_name'];?> Price: <?php echo $row['price'];?></h5>
            <div class="card-body">
              <p class="card-text"></p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                    <a href="images/<?php echo $row['product_img'];?>"><button type="button" class="btn btn-sm btn-outline-secondary">View</button></a>
                </div>
            </div>
          </div>
        </div>
    </div>
           <?php }?>
  </div>       
  </div>
  </div>
</main>
       <footer></footer>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>

</html>
