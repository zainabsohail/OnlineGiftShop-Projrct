<style>
.dropbtn {
    
    font-family: 'Arvo',courier, serif ;
  background-color: white;
  color: #e74c3c;
  padding: 16px;
  font-size: 16px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  
    font-family: 'Arvo',courier, serif ;
  color: #e74c3c;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: white;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: white;}
</style>
<header>
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation" style=" background-color: white;">
      <div class="container" style="padding-bottom: 32px;">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
            <a class="navbar-brand" href="index.php"><img src="images/valentines-logo.png" alt="logo" title="giftshoplogo" style="margin-top: 0px;"></a>
        </div>
          <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <div class="dropdown">
                        <button class="dropbtn">Ocassions</button>
                            <div class="dropdown-content">
                              <a href="delizia.php">BIRTHDAY</a>
                              <a href="choco.php">ANNIVERSARY</a>
                              <a href="gift.php">GET WELL</a>
                            </div>
                      </div>
                </li>
                <li>
                    <div class="dropdown">
                        <button class="dropbtn">Cakes And Confectionery</button>
                            <div class="dropdown-content">
                              <a href="choco.php">CHOCOLATES</a>
                              <a href="delizia.php">CAKES</a>
                              <a href="gift.php">CHOCOLATE BASKET</a>
                            </div>
                      </div>
                </li>
                <li>
                    <div class="dropdown">
                        <button class="dropbtn">Flowers</button>
                            <div class="dropdown-content">
                              <a href="flower.php">ROSES</a>
                              <a href="flower.php">LILIES</a>
                              <a href="flower.php">FLOWER COMBOS</a>
                            </div>
                      </div>
                </li>
                <li>
                    <div class="dropdown">
                        <button class="dropbtn">Gift Basket</button>
                            <div class="dropdown-content">
                                <a href="gift.php">CHOCOLATE BASKET</a>
                            </div>
                      </div>
                </li>
            <li><a href="signup.php" style="font-family: 'Arvo',courier, serif ;font-size: 15px;color: #e74c3c;">Sign Up</a></li>
            <li><a href="signin.php" style="font-family: 'Arvo',courier, serif ;font-size: 15px;color: #e74c3c;">Sign In</a></li>
            <li><a href="signout.php" style="font-family: 'Arvo',courier, serif ;font-size: 15px;color: #e74c3c;">Sign Out</a>
            </li>
  
          </ul>
        </div>
        </div>
    </nav>
</header>
