<footer style="background-color: #e74c3c;
	padding-top: 100px;">
  <div class="container">
    <p class="float-right"> 
       
    </p>
  </div>
</footer> 